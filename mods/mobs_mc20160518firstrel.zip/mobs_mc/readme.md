
MC MOBS
WIP
assembled by maikerumine
compatable with mobs redo api


Chicken

- Found in green areas (bamboo biome in ethereal) and lays eggs on flat ground, Can be picked up and placed in inventory and gives 1-2 raw chicken when killed. Feed 8x wheat seed to breed.

Cow

- Wanders around eating grass/wheat and can be right-clicked with empty bucket to get milk. Cows will defend themselves when hit and can be right-clicked with 8x wheat to tame and breed.

Sheep

- Green grass and wheat munchers that can be clipped using shears to give 1-3 wool. Feed sheep 8x wheat to regrow wool, tame and breed. Will drop 1-3 meat when killed.


Note: After breeding animals need to rest for 4 minutes, baby animals take 4 minutes to grow up and feeding them helps them grow quicker...
