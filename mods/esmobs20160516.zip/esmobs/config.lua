--esmobs v1.3
--maikerumine
--made for Extreme Survival game
--License for code WTFPL

--[[
-----------------------------------------------------------------------------
-- You decide which mobs and how many will spawn
-----------------------------------------------------------------------------
-- set to true to have cute, happy little aminals to ride and play with!
esmobs.animals = true;

-- if set to true,  The Minetest monsters will spawn like sand, dirt, tree, stone monster and oerkii will spawn.
esmobs.mt_monsters = true;

-- if set to true, The good guys will spawn and you can use them to help fight monsters.
esmobs.good_npc = true;

-- if set to true, the baddies will spawn and they look like good npc!
esmobs.bad_npc = true;
]]
-- if set to given number, You will get all the mobs in the set mob package.  (see below for configuration)

esmobs.MOB_SETTING = 5;


-----------------------------------------------------------------------------
--MOB PACKAGES
-----------------------------------------------------------------------------

--esmobs.MOB_SETTING = 5;		Animals, Good npc, monsters, and Bad npc's. All of them.
--esmobs.MOB_SETTING = 4;		Animals, Good npc, and monsters.
--esmobs.MOB_SETTING = 3;		Good npc, Bad npc, and monsters.
--esmobs.MOB_SETTING = 2;		Animals and good npc's.
--esmobs.MOB_SETTING = 1;		Just Animals.








