--MCmobs v0.2
--maikerumine
--made for MC like Survival game
--License for code WTFPL and otherwise stated in readmes


dofile(minetest.get_modpath("mobs").."/api.lua")

-------------------------
--KPGMOBS HORSE
-------------------------
--By: KrupnovPavel
--Tweaked by: maikerumine
local function is_ground(pos)
	local nn = minetest.get_node(pos).name
	return minetest.get_item_group(nn, "crumbly") ~= 0 or
	minetest.get_item_group(nn, "choppy") ~= 0 or
	minetest.get_item_group(nn, "cracky") ~= 0  or
	minetest.get_item_group(nn, "snappy") ~= 0  or
	minetest.get_item_group(nn, "unbreakable") ~= 0  or
	minetest.get_item_group(nn, "immortal") ~= 0
end

local function get_sign(i)
	if i == 0 then
		return 0
	else
		return i/math.abs(i)
	end
end

local function get_velocity(v, yaw, y)
	local x = math.cos(yaw)*v
	local z = math.sin(yaw)*v
	return {x=x, y=y, z=z}
end

local function get_v(v)
	return math.sqrt(v.x^2+v.z^2)
end

function merge(a, b)
    if type(a) == 'table' and type(b) == 'table' then
        for k,v in pairs(b) do if type(v)=='table' and type(a[k] or false)=='table' then merge(a[k],v) else a[k]=v end end
    end
    return a
end

-- HORSE go go goooo :)
local horse = {
	physical = true,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	stepheight = 1.1,
	visual_size = {x=1,y=1},
	mesh = "mobs_horseh1.x",
	driver = nil,
	v = 0,

	on_rightclick = function(self, clicker)
		if not clicker or not clicker:is_player() then
			return
		end
		if self.driver and clicker == self.driver then
			self.driver = nil
			clicker:set_detach()
		elseif not self.driver then
			self.driver = clicker
			clicker:set_attach(self.object, "", {x=0,y=11,z=0}, {x=0,y=0,z=0})
			self.object:setyaw(clicker:get_look_yaw())
		end
	end,

	on_activate = function(self, staticdata, dtime_s)
		self.object:set_armor_groups({immortal=1})
		print (self.texture, self.jmp)
	end,

	on_punch = function(self, puncher, time_from_last_punch, tool_capabilities, direction)
		if puncher and puncher:is_player() then
			puncher:get_inventory():add_item("main", self.name)
			self.object:remove()
		end
	end,

	on_step = function(self, dtime)

		self.v = get_v(self.object:getvelocity())*get_sign(self.v)

		if self.driver then
			local ctrl = self.driver:get_player_control()
			if ctrl.up then
				self.v = self.v + self.jmp
			end
			if ctrl.down then
				self.v = self.v-0.1
			end
			if ctrl.left then
				self.object:setyaw(self.object:getyaw()+math.pi/120+dtime*math.pi/120)
			end
			if ctrl.right then
				self.object:setyaw(self.object:getyaw()-math.pi/120-dtime*math.pi/120)
			end
			if ctrl.jump then
				local p = self.object:getpos()
				p.y = p.y-0.5
				if is_ground(p) then
					local pos = self.object:getpos()
					pos.y = math.floor(pos.y)+4
					self.object:setpos(pos)
					self.object:setvelocity(get_velocity(self.v, self.object:getyaw(), 0))
				end
			end
		end

		local s = get_sign(self.v)
		self.v = self.v - 0.02*s
		if s ~= get_sign(self.v) then
			self.object:setvelocity({x=0, y=0, z=0})
			self.v = 0
			return
		end

		if math.abs(self.v) > 4.5 then
			self.v = 4.5*get_sign(self.v)
		end

		local p = self.object:getpos()
		p.y = p.y-0.5

		if not is_ground(p) then
			if minetest.registered_nodes[minetest.get_node(p).name].walkable then
				self.v = 0
			end
			self.object:setacceleration({x=0, y=-10, z=0})
			self.object:setvelocity(get_velocity(self.v, self.object:getyaw(), self.object:getvelocity().y))
		else
			p.y = p.y+1
			if is_ground(p) then
				self.object:setacceleration({x=0, y=3, z=0})
				local y = self.object:getvelocity().y
				if y > 2 then
					y = 2
				end
				if y < 0 then
					self.object:setacceleration({x=0, y=10, z=0})
				end
				self.object:setvelocity(get_velocity(self.v, self.object:getyaw(), y))
			else
				self.object:setacceleration({x=0, y=0, z=0})
				if math.abs(self.object:getvelocity().y) < 1 then
					local pos = self.object:getpos()
					pos.y = math.floor(pos.y)+0.5
					self.object:setpos(pos)
					self.object:setvelocity(get_velocity(self.v, self.object:getyaw(), 0))
				else
					self.object:setvelocity(get_velocity(self.v, self.object:getyaw(), self.object:getvelocity().y))
				end
			end
		end
	end,
}

--END HORSE

-- backup table
local hbak = horse

-- Brown Horse
local hrs = {
	textures = {"mobs_horseh1.png"},
	jmp = 2,
}
minetest.register_entity("mobs:horseh1", merge(hrs, horse))

-- White Horse
horse = hbak
local peg = {
	textures = {"mobs_horsepegh1.png"},
	jmp = 2,
}
minetest.register_entity("mobs:horsepegh1", merge(peg, horse))

-- Black Horse
horse = hbak
local ara = {
	textures = {"mobs_horsearah1.png"},
	jmp = 3,
}
minetest.register_entity("mobs:horsearah1", merge(ara, horse))


mobs:register_mob("mobs:horse", {
	type = "animal",
	hp_min = 5,
	hp_max = 10,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {
		{"mobs_horseh.png"},
	},
	visual = "mesh",
	mesh = "mobs_horse.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 15,
		stand_start = 25,		stand_end = 75,
		walk_start = 75,		walk_end = 100,
	},
	follow = "farming:wheat",
	view_range = 5,

	on_rightclick = function(self, clicker)
		local tool = clicker:get_wielded_item()
		if tool:get_name() == "mobs:saddle" then
			clicker:get_inventory():remove_item("main", "mobs:saddle")
			local pos = self.object:getpos()
			self.object:remove()
			minetest.add_entity(pos, "mobs:horseh1")
		end
	end,
})

mobs:register_mob("mobs:horse2", {
	type = "animal",
	hp_min = 5,
	hp_max = 10,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {
		{"mobs_horsepegh.png"},
	},
	visual = "mesh",
	mesh = "mobs_horse.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 15,
		stand_start = 25,		stand_end = 75,
		walk_start = 75,		walk_end = 100,
	},
	follow = "farming:wheat",
	view_range = 5,

	on_rightclick = function(self, clicker)
		local tool = clicker:get_wielded_item()
		if tool:get_name() == "mobs:saddle" then
			clicker:get_inventory():remove_item("main", "mobs:saddle")
			local pos = self.object:getpos()
			self.object:remove()
			minetest.add_entity(pos, "mobs:horsepegh1")
		end
	end,
})

mobs:register_mob("mobs:horse3", {
	type = "animal",
	hp_min = 5,
	hp_max = 10,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {
		{"mobs_horsearah.png"},
	},
	visual = "mesh",
	mesh = "mobs_horse.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 15,
		stand_start = 25,		stand_end = 75,
		walk_start = 75,		walk_end = 100,
	},
	follow = "farming:wheat",
	view_range = 5,

	on_rightclick = function(self, clicker)
		local tool = clicker:get_wielded_item()
		if tool:get_name() == "mobs:saddle" then
			clicker:get_inventory():remove_item("main", "mobs:saddle")
			local pos = self.object:getpos()
			self.object:remove()
			minetest.add_entity(pos, "mobs:horsearah1")
		end
	end,
})
mobs:register_spawn("mobs:horse", {"default:dirt_with_dry_grass","es:strange_grass","es:aiden_grass"}, 20, 12, 21000, 1, 12)
mobs:register_spawn("mobs:horse2", {"default:dirt_with_dry_grass"}, 20, 12, 23000, 1, 31000)
mobs:register_spawn("mobs:horse3", {"default:desert_sand"}, 20, 8, 17000, 1, 5)


-- Dog
mobs:register_mob("mobs:dog", {
	type = "npc",
	passive = true,
	hp_max = 55,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "mobs_wolf.x",
	textures = {
		{"mobs_dog.png"},
	},
	makes_footstep_sound = true,
	sounds = {
		war_cry = "mobs_wolf_attack",
	},
	view_range = 15,
	stepheight = 1.1,
	owner = "",
	order = "follow",
	floats = {x=0,y=0,z=0},
	walk_velocity = 4,
	run_velocity = 4,
	stepheight = 1.1,
	damage = 3,
	armor = 200,
	attacks_monsters = true,
	attack_type = "dogfight",
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = function(self, clicker)
		local item = clicker:get_wielded_item()
		if item:get_name() == "mobs:meat_raw" then
			local hp = self.object:get_hp()
			if hp + 4 > self.hp_max then return end
			if not minetest.setting_getbool("creative_mode") then
				item:take_item()
				clicker:set_wielded_item(item)
			end
			self.object:set_hp(hp+4)
		else
			if self.owner == "" then
				self.owner = clicker:get_player_name()
			else
				local formspec = "size[8,4]"
				formspec = formspec .. "textlist[2.85,0;2.1,0.5;dialog;What can I do for you?]"
				formspec = formspec .. "button_exit[1,1;2,2;dfollow;follow]"
				formspec = formspec .. "button_exit[5,1;2,2;dstand;stand]"
				formspec = formspec .. "button_exit[0,2;4,4;dfandp;follow and protect]"
				formspec = formspec .. "button_exit[4,2;4,4;dsandp;stand and protect]"
				formspec = formspec .. "button_exit[1,2;2,2;dgohome; go home]"
				formspec = formspec .. "button_exit[5,2;2,2;dsethome; sethome]"
				minetest.show_formspec(clicker:get_player_name(), "order", formspec)
				minetest.register_on_player_receive_fields(function(clicker, formname, fields)
					if fields.dfollow then
						self.order = "follow"
						self.attacks_monsters = false
					end
					if fields.dstand then
						self.order = "stand"
						self.attacks_monsters = false
					end
					if fields.dfandp then
						self.order = "follow"
						self.attacks_monsters = true
					end
					if fields.dsandp then
						self.order = "stand"
						self.attacks_monsters = true
					end
					if fields.dsethome then
						self.floats = self.object:getpos()
					end
					if fields.dgohome then
						if self.floats then
							self.order = "stand"
							self.object:setpos(self.floats)
						end
					end
				end)
			end
		end
	end,
	animation = {
		speed_normal = 20,
		speed_run = 30,
		stand_start = 10,
		stand_end = 20,
		walk_start = 75,
		walk_end = 100,
		run_start = 100,
		run_end = 130,
		punch_start = 135,
		punch_end = 155,
	},
	jump = true,
	step = 1,
	blood_texture = "mobs_blood.png",
})


-- Wolf by KrupnoPavel
mobs:register_mob("mobs:wolf", {
	type = "animal",
	hp_max = 55,
	passive = false,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "mobs_wolf.x",
	textures = {
		{"mobs_wolf.png"},
	},
	makes_footstep_sound = true,
	sounds = {
		war_cry = "mobs_wolf_attack",
	},
	view_range = 7,
	walk_velocity = 2,
	run_velocity = 3,
	stepheight = 1.1,
	damage = 3,
	armor = 200,
	attack_type = "dogfight",
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = function(self, clicker)
		tool = clicker:get_wielded_item()
		local dog
		local ent
		if tool:get_name() == "mobs:meat_raw" then
			clicker:get_inventory():remove_item("main", "mobs:meat_raw")
			dog = minetest.add_entity(self.object:getpos(), "mobs:dog")
			ent = dog:get_luaentity()
			ent.owner = clicker:get_player_name()
			self.object:remove()
		end
	end,
	animation = {
		speed_normal = 20,
		speed_run = 30,
		stand_start = 10,
		stand_end = 20,
		walk_start = 75,
		walk_end = 100,
		run_start = 100,
		run_end = 130,
		punch_start = 135,
		punch_end = 155,
	},
	jump = true,
	step = 0.5,
	blood_texture = "mobs_blood.png",
})
mobs:register_spawn("mobs:wolf", {"default:dirt_with_grass","default:dirt","default:snow", "default:snowblock"}, 20, 0, 19000, 1, 31000)

--mt sheep
local all_colours = {
	{"black",      "Black",      "#000000b0"},
	{"blue",       "Blue",       "#015dbb70"},
	{"brown",      "Brown",      "#663300a0"},
	{"cyan",       "Cyan",       "#01ffd870"},
	{"dark_green", "Dark Green", "#005b0770"},
	{"dark_grey",  "Dark Grey",  "#303030b0"},
	{"green",      "Green",      "#61ff0170"},
	{"grey",       "Grey",       "#5b5b5bb0"},
	{"magenta",    "Magenta",    "#ff05bb70"},
	{"orange",     "Orange",     "#ff840170"},
	{"pink",       "Pink",       "#ff65b570"},
	{"red",        "Red",        "#ff0000a0"},
	{"violet",     "Violet",     "#2000c970"},
	{"white",      "White",      "#abababc0"},
	{"yellow",     "Yellow",     "#e3ff0070"},
}

-- Sheep by PilzAdam, texture converted to minetest by AMMOnym from Summerfield pack

for _, col in pairs(all_colours) do

	mobs:register_mob("mobs:sheep_"..col[1], {
		type = "animal",
		passive = true,
		hp_min = 8,
		hp_max = 10,
		armor = 200,
		collisionbox = {-0.5, -1, -0.5, 0.5, 0.3, 0.5},
		visual = "mesh",
		mesh = "mobs_sheep.b3d",
		textures = {
			{"mobs_sheep_base.png^(mobs_sheep_wool.png^[colorize:" .. col[3] .. ")"},
		},
		gotten_texture = {"mobs_sheep_shaved.png"},
		gotten_mesh = "mobs_sheep_shaved.b3d",
		makes_footstep_sound = true,
		sounds = {
			random = "mobs_sheep",
		},
		walk_velocity = 1,
		run_velocity = 2,
		runaway = true,
		jump = true,
		drops = {
			{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
			--{name = "wool:"..col[1], chance = 1, min = 1, max = 1},
		},
		water_damage = 1,
		lava_damage = 5,
		light_damage = 0,
		animation = {
			speed_normal = 15,
			speed_run = 15,
			stand_start = 0,
			stand_end = 80,
			walk_start = 81,
			walk_end = 100,
		},
		follow = {"farming:wheat", "default:grass_5"},
		view_range = 8,
		replace_rate = 10,
		replace_what = {"default:grass_3", "default:grass_4", "default:grass_5", "farming:wheat_8"},
		replace_with = "air",
		replace_offset = -1,
		fear_height = 3,

		on_rightclick = function(self, clicker)

			--are we feeding?
			if mobs:feed_tame(self, clicker, 8, true, true) then

				--if full grow fuzz
				if self.gotten == false then

					self.object:set_properties({
						textures = {"mobs_sheep_base.png^(mobs_sheep_wool.png^[colorize:" .. col[3] .. ")"},
						mesh = "mobs_sheep.b3d",
					})
				end

				return
			end

			local item = clicker:get_wielded_item()
			local itemname = item:get_name()

			--are we giving a haircut>
			if itemname == "mobs:shears" then

				if self.gotten ~= false
				and self.child ~= false
				and not minetest.get_modpath("wool") then
					return
				end

				self.gotten = true -- shaved

				local obj = minetest.add_item(
					self.object:getpos(),
					ItemStack( "wool:" .. col[1] .. " " .. math.random(1, 3) )
				)

				if obj then

					obj:setvelocity({
						x = math.random(-1, 1),
						y = 5,
						z = math.random(-1, 1)
					})
				end

				item:add_wear(650) -- 100 uses

				clicker:set_wielded_item(item)

				self.object:set_properties({
					textures = {"mobs_sheep_shaved.png"},
					mesh = "mobs_sheep_shaved.b3d",
				})

				return
			end

			local name = clicker:get_player_name()

			--are we coloring?
			if itemname:find("dye:") then

				if self.gotten == false
				and self.child == false
				and self.tamed == true
				and name == self.owner then

					local colr = string.split(itemname, ":")[2]

					for _,c in pairs(all_colours) do

						if c[1] == colr then

							local pos = self.object:getpos()

							self.object:remove()

							local mob = minetest.add_entity(pos, "mobs_animal:sheep_" .. colr)
							local ent = mob:get_luaentity()

							ent.owner = name
							ent.tamed = true

							-- take item
							if not minetest.setting_getbool("creative_mode") then
								item:take_item()
								clicker:set_wielded_item(item)
							end

							break
						end
					end
				end

				return
			end

			--are we capturing?
			mobs:capture_mob(self, clicker, 0, 5, 60, false, nil)
		end
	})

	mobs:register_egg("mobs:sheep_"..col[1], col[2] .. " Sheep", "wool_"..col[1]..".png", 1)

	-- compatibility
	--mobs:alias_mob("mobs:sheep_" .. col[1], "mobs_animal:sheep_" .. col[1])

end

mobs:register_spawn("mobs:sheep_white",
	{"default:dirt_with_grass", "ethereal:green_dirt"}, 20, 10, 15000, 1, 31000, true)


-- compatibility
--mobs:alias_mob("mobs:sheep", "mobs_animal:sheep_white")
mobs:alias_mob("mobs:sheep", "mobs:sheep_white")

--[[
--mcsheep
mobs:register_mob("mobs:sheep", {
	type = "animal",
	hp_max = 25,
	collisionbox = {-0.5, -0.01, -0.5, 0.5, 1.5, 0.5},
	textures = {"sheep.png"},
	visual = "mesh",
	mesh = "sheep.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 1,
		max = 2,},
		{name = "wool:white",
		chance = 1,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 3,
	sounds = {
		random = "Sheep3",
		death = "Sheep3",
		damage = "Sheep3",
	},
	animation = {
		speed_normal = 24,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		hurt_start = 118,
		hurt_end = 154,
		death_start = 154,
		death_end = 179,
		eat_start = 49,
		eat_end = 78,
		look_start = 78,
		look_end = 108,
	},
	follow = "farming:wheat",
	view_range = 5,
	
	on_rightclick = function(self, clicker)
		local item = clicker:get_wielded_item()
		if item:get_name() == "farming:wheat" then
			if not self.tamed then
				if not minetest.setting_getbool("creative_mode") then
					item:take_item()
					clicker:set_wielded_item(item)
				end
				self.tamed = true
			elseif self.naked then
				if not minetest.setting_getbool("creative_mode") then
					item:take_item()
					clicker:set_wielded_item(item)
				end
				self.food = (self.food or 0) + 1
				if self.food >= 4 then
					self.food = 0
					self.naked = false
					self.object:set_properties({
						textures = {"sheep.png"},
					})
				end
			end
			return
		end
		if item:get_name() == "shears:shears" and not self.naked then
			self.naked = true
			local pos = self.object:getpos()
			minetest.sound_play("shears", {pos = pos})
			pos.y = pos.y + 0.5
			if not self.color then
				minetest.add_item(pos, ItemStack("wool:white "..math.random(1,3)))
			else
				minetest.add_item(pos, ItemStack("wool:"..self.color.." "..math.random(1,3)))
			end
			self.object:set_properties({
				textures = {"sheep_sheared.png"},
			})
			if not minetest.setting_getbool("creative_mode") then
				item:add_wear(300)
				clicker:get_inventory():set_stack("main", clicker:get_wield_index(), item)
			end
		end
		if minetest.get_item_group(item:get_name(), "dye") == 1 and not self.naked then
print(item:get_name(), minetest.get_item_group(item:get_name(), "dye"))
			local name = item:get_name()
			local pname = name:split(":")[2]

			self.object:set_properties({
				textures = {"sheep_"..pname..".png"},
			})
			self.color = pname
			self.drops = {
				{name = "mobs:meat_raw",
				chance = 1,
				min = 1,
				max = 2,},
				{name = "wool:"..self.color,
				chance = 1,
				min = 1,
				max = 1,},
			}
		end
	end,
})
mobs:register_spawn("mobs:sheep", {"default:dirt_with_grass"}, 20, 12, 5000, 2, 31000)
]]

mobs:register_mob("mobs:pig", {
	type = "animal",
	hp_max = 25,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"pig.png"},
	visual = "mesh",
	mesh = "pig.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:pork_raw",
		chance = 1,
		min = 1,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 3,
	sounds = {
		random = "Pig2",
		death = "Pigdeath",
		damage = "Pig2",
	},
	animation = {
		speed_normal = 24,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		hurt_start = 118,
		hurt_end = 154,
		death_start = 154,
		death_end = 179,
		eat_start = 49,
		eat_end = 78,
		look_start = 78,
		look_end = 108,
	},
	follow = "farming:carrot",
	view_range = 5,
	on_rightclick = function(self, clicker)
		if not clicker or not clicker:is_player() then
			return
		end
		local item = clicker:get_wielded_item()
		if item:get_name() == "mobs:saddle" and self.saddle ~= "yes" then
			self.object:set_properties({
				textures = {"pig_with_saddle.png"},
			})
			self.saddle = "yes"
			self.tamed = true
			self.drops = {
				{name = "mobs:pork_raw",
				chance = 1,
				min = 1,
				max = 3,},
				{name = "mobs:saddle",
				chance = 1,
				min = 1,
				max = 1,},
			}
			if not minetest.setting_getbool("creative_mode") then
				local inv = clicker:get_inventory()
				local stack = inv:get_stack("main", clicker:get_wield_index())
				stack:take_item()
				inv:set_stack("main", clicker:get_wield_index(), stack)
			end
			return
		end
	-- from boats mod
	local name = clicker:get_player_name()
	if self.driver and clicker == self.driver then
		self.driver = nil
		clicker:set_detach()
		default.player_attached[name] = false
		default.player_set_animation(clicker, "stand" , 30)
	elseif not self.driver and self.saddle == "yes" then
		self.driver = clicker
		clicker:set_attach(self.object, "", {x = 0, y = 19, z = 0}, {x = 0, y = 0, z = 0})
		default.player_attached[name] = true
		minetest.after(0.2, function()
			default.player_set_animation(clicker, "sit" , 30)
		end)
		--self.object:setyaw(clicker:get_look_yaw() - math.pi / 2)
	end
	end,
})
mobs:register_spawn("mobs:pig", {"default:dirt_with_grass"}, 20, 12, 5000, 1, 31000)
	

mobs:register_mob("mobs:cow", {
	type = "animal",
	hp_max = 28,
	collisionbox = {-0.6, -0.01, -0.6, 0.6, 1.8, 0.6},
	textures = {"cow.png"},
	visual = "mesh",
	mesh = "cow.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:beef_raw",
		chance = 1,
		min = 1,
		max = 3,},
		{name = "mobs:leather",
		chance = 1,
		min = 0,
		max = 2,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 3,
	sounds = {
		random = "Cow1",
		death = "Cowhurt1",
		damage = "Cowhurt1",
	},
	animation = {
		speed_normal = 24,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		hurt_start = 118,
		hurt_end = 154,
		death_start = 154,
		death_end = 179,
		eat_start = 49,
		eat_end = 78,
		look_start = 78,
		look_end = 108,
	},
	follow = "farming:wheat",
	view_range = 5,
	on_rightclick = function(self, clicker)
		local item = clicker:get_wielded_item()
		if item:get_name() == "bucket:bucket_empty" and clicker:get_inventory() then
			local inv = clicker:get_inventory()
			inv:remove_item("main", "bucket:bucket_empty")
			-- if room add bucket of milk to inventory, otherwise drop as item
			if inv:room_for_item("main", {name="mobs:bucket_milk"}) then
				clicker:get_inventory():add_item("main", "mobs:bucket_milk")
			else
				local pos = self.object:getpos()
				pos.y = pos.y + 0.5
				minetest.add_item(pos, {name = "mobs:bucket_milk"})
			end
		end
	end,
})
mobs:register_spawn("mobs:cow", {"default:dirt_with_grass"}, 20, 8, 7000, 1, 31000)


mobs:register_mob("mobs:chicken", {
	type = "animal",
	hp_max = 24,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"chicken.png"},
	visual = "mesh",
	mesh = "chicken.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "mobs:chicken_raw",
		chance = 1,
		min = 1,
		max = 1,},
		{name = "mobs:feather",
		chance = 1,
		min = 0,
		max = 2,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	sounds = {
		random = "Chicken1",
		death = "Chickenhurt1",
		hurt = "Chickenhurt1",
	},
	animation = {
		speed_normal = 24,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		hurt_start = 118,
		hurt_end = 154,
		death_start = 154,
		death_end = 179,
		eat_start = 49,
		eat_end = 78,
		look_start = 78,
		look_end = 108,
		fly_start = 181,
		fly_end = 187,
	},
	follow = "farming:seed_wheat",
	view_range = 5,
	on_rightclick = function(self, clicker)
		if clicker:get_inventory() then
			if minetest.registered_items["food:egg"] then
				clicker:get_inventory():add_item("main", ItemStack("food:egg 1"))
			end
		end
	end,
})
mobs:register_spawn("mobs:chicken", {"default:dirt_with_grass"}, 20, 8, 7000, 1, 31000)



mobs:register_mob("mobs:creeper", {
	type = "monster",
	hp_max = 30,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.6, 0.4},
	textures = {"creeper.png"},
	visual = "mesh",
	visual_size = {x=.75, y=.75, z=.75},
	mesh = "creeper.x",
	makes_footstep_sound = false,
	sounds = {
		attack = "Fuse",
		death = "Creeperdeath",
		damage = "Creeper4",
		war_cry = "Fuse",
		explode = "explo",
	},
	walk_velocity = 1.5,
	run_velocity = 3,
	damage = 1,
	armor = 200,
	maxdrops = 3,
	drops = {
		{name = "tnt:gunpowder",
		chance = 1,
		min = 0,
		max = 2,},
		{name = "farorb:farorb",
		chance = 1,
		min = 0,
		max = 1,},
		{name = "jdukebox:disc_1",
		chance = 10,
		min = 1,
		max = 1,},
		{name = "jdukebox:disc_2",
		chance = 10,
		min = 1,
		max = 1,},
		{name = "jdukebox:disc_3",
		chance = 10,
		min = 1,
		max = 1,},
		{name = "jdukebox:disc_4",
		chance = 10,
		min = 1,
		max = 1,},
		{name = "jdukebox:disc_5",
		chance = 10,
		min = 1,
		max = 1,},
		{name = "jdukebox:disc_6",
		chance = 10,
		min = 1,
		max = 1,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		run_start = 24,
		run_end = 49,
		hurt_start = 110,
		hurt_end = 139,
		death_start = 140,
		death_end = 189,
		look_start = 50,
		look_end = 108,
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	view_range = 16,
	attack_type = "explode",
})
mobs:register_spawn("mobs:creeper", {"group:crumbly", "group:cracky", "group:choppy", "group:snappy"}, 7, -1, 5000, 4, 31000)



mobs:register_mob("mobs:skeleton", {
	type = "monster",
	hp_max = 30,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	textures = {"skeleton.png"},
	visual = "mesh",
	mesh = "skeleton.x",
	makes_footstep_sound = true,
	sounds = {
		random = "skeleton1",
		death = "skeletondeath",
		damage = "skeletonhurt1",
	},
	walk_velocity = 1.2,
	run_velocity = 2.4,
	damage = 1,
	armor = 200,
	drops = {
		{name = "mobs:arrow",
		chance = 1,
		min = 0,
		max = 2,},
		{name = "mobs:bow_wood",
		chance = 11,
		min = 1,
		max = 1,},
		{name = "bones:bones",
		chance = 1,
		min = 0,
		max = 2,},
	},
	animation = {
		speed_normal = 30,
		speed_run = 60,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		run_start = 24,
		run_end = 49,
		hurt_start = 85,
		hurt_end = 115,
		death_start = 117,
		death_end = 145,
		shoot_start = 50,
		shoot_end = 82,
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 1,
	view_range = 16,
	attack_type = "dogshoot",
	arrow = "mobs:arrow_entity",
	shoot_interval = 2.5,
	shoot_offset = 1,
	--'dogshoot_switch' allows switching between shoot and dogfight modes inside dogshoot using timer (1 = shoot, 2 = dogfight)
	--'dogshoot_count_max' number of seconds before switching above modes.
	dogshoot_switch = 1,
	dogshoot_count_max =3,
})
mobs:register_spawn("mobs:skeleton", {"group:crumbly", "group:cracky", "group:choppy", "group:snappy"}, 7, -1, 5000, 4, 31000)


mobs:register_mob("mobs:zombie", {
	type = "monster",
	hp_max = 35,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	textures = {"zombie.png"},
	visual = "mesh",
	mesh = "zombie.x",
	makes_footstep_sound = true,
	sounds = {
		random = "zombie1",
		death = "zombiedeath",
		damage = "zombiehurt1",
		attack = "default_punch3",
	},
	walk_velocity = .8,
	run_velocity = 1.6,
	damage = 1,
	armor = 200,
	drops = {
		{name = "mobs:rotten_flesh",
		chance = 1,
		min = 1,
		max = 1,},
		{name = "default:steel_ingot",
		chance = 3,
		min = 0,
		max = 2,},
		{name = "default:shovel_steel",
		chance = 4,
		min = 1,
		max = 1,},
		{name = "default:sword_steel",
		chance = 8,
		min = 1,
		max = 1,},
		{name = "farming:carrot",
		chance = 10,
		min = 1,
		max = 1,},
		{name = "farming:potato",
		chance = 10,
		min = 1,
		max = 1,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 1,
	view_range = 16,
	attack_type = "dogfight",
})
mobs:register_spawn("mobs:zombie", {"group:crumbly", "group:cracky", "group:choppy", "group:snappy"}, 7, -1, 5000, 4, 31000)


mobs:register_mob("mobs:pigman", {
	type = "monster",
	hp_max = 35,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	textures = {"zombie_pigman.png"},
	visual = "mesh",
	mesh = "zombie.x",
	
	--Tried to get a sword in pig hand
	--collisionbox = {-0.3, -1.0, -0.3, 0.3, 0.8, 0.3},
	--visual = "mesh",
	--mesh = "3d_armor_character.b3d",
	--textures = {"zombie_pigman.png",
	--		"3d_armor_trans.png",
	--			minetest.registered_items["default:sword_mese"].inventory_image,
	--		},

	makes_footstep_sound = true,
	walk_velocity = .8,
	run_velocity = 1.6,
	damage = 2,
	armor = 400,
	drops = {
		{name = "mobs:rotten_flesh",
		chance = 1,
		min = 1,
		max = 1,},
		{name = "default:gold_ingot",
		chance = 13,
		min = 0,
		max = 2,},
		{name = "default:sword_mese",
		chance = 8,
		min = 1,
		max = 1,},
	},
		sounds = {
		random = "Pig2",
		death = "Pigdeath",
		damage = "zombiehurt1",
		attack = "default_punch3",
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 1,
	view_range = 16,
	attack_type = "dogfight",
})
mobs:register_spawn("mobs:pigman", {"nether:rack"}, 15, -1, 5000, 4, -5000)
mobs:register_spawn("mobs:pigman", {"nether:portal"}, 15, -1, 15000, 4, 31000)
mobs:register_spawn("mobs:pigman", {"default:obsidian"}, 15, -1, 19000, 1, 31000)


mobs:register_mob("mobs:greensmall", {
	type = "monster",
	pathfinding = true,
	group_attack = true,
	hp_max = 5,
	collisionbox = {-0.2, -0.4, -0.2, 0.2, 0.2, 0.2},
	visual_size = {x=0.5, y=0.5},
	textures = {"green_slime_top.png", "green_slime_bottom.png", "green_slime_front.png", "green_slime_sides.png", "green_slime_sides.png", "green_slime_sides.png"},
	visual = "cube",
	blood_texture ="green_slime_blood.png",
	rotate = 270,
	makes_footstep_sound = true,
	sounds = {
		jump = "green_slime_jump",
		death = "green_slime_death",
		damage = "green_slime_damage",
		attack = "green_slime_attack",
	},
	walk_velocity = .8,
	run_velocity = 2.6,
	damage = 1,
	armor = 100,
	drops = {
		{name = "mesecons_materials:glue 1",
		chance = 3,
		min = 1,
		max = 4,},
		{name = "default:grass",
		chance = 1,
		min = 1,
		max = 5,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 10,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 4,
	jump_chance = 98,
	fear_height = 12,	
})

mobs:register_mob("mobs:greenmedium", {
	type = "monster",
	pathfinding = true,
	group_attack = true,
	hp_max = 10,
	collisionbox = {-0.55, -0.55, -0.55, 0.55, 0.55, 0.55},
	visual_size = {x=1.0, y=1.0},
	textures = {"green_slime_top.png", "green_slime_bottom.png", "green_slime_front.png", "green_slime_sides.png", "green_slime_sides.png", "green_slime_sides.png"},
	visual = "cube",
	blood_texture ="green_slime_blood.png",
	rotate = 270,
	makes_footstep_sound = true,
	sounds = {
		jump = "green_slime_jump",
		death = "green_slime_death",
		damage = "green_slime_damage",
		attack = "green_slime_attack",
	},
	walk_velocity = .8,
	run_velocity = 2.0,
	damage = 2,
	armor = 100,
	drops = {
		{name = "default:mossycobble",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "default:leaves",
		chance = 1,
		min = 1,
		max = 5,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 10,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 8,
	jump_chance = 100,
	fear_height = 60,
	on_die =function(self, pos)
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:greensmall")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:greensmall")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:greensmall")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:greensmall")
			ent = lavasmall:get_luaentity()
			end
})

mobs:register_mob("mobs:greenbig", {
	type = "monster",
	pathfinding = true,
	group_attack = true,
	hp_max = 25,
	collisionbox = {-0.75, -0.75, -0.75, 0.75, 0.75, 0.75},
	visual_size = {x=1.5, y=1.5},
	textures = {"green_slime_top.png", "green_slime_bottom.png", "green_slime_front.png", "green_slime_sides.png", "green_slime_sides.png", "green_slime_sides.png"},
	visual = "cube",
	blood_texture ="green_slime_blood.png",
	rotate = 270,
	makes_footstep_sound = true,
	sounds = {
		jump = "green_slime_jump",
		death = "green_slime_death",
		damage = "green_slime_damage",
		attack = "green_slime_attack",
	},
	walk_velocity = .8,
	run_velocity = 1.6,
	damage = 2,
	armor = 100,
	drops = {
		{name = "default:leaves",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "default:papyrus",
		chance = 1,
		min = 1,
		max = 5,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 10,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 8,
	jump_chance = 100,
	fear_height = 60,
	on_die =function(self, pos)
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:greenmedium")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:greenmedium")
			ent = lavasmall:get_luaentity()
			end
})
mobs:register_spawn("mobs:greensmall", {"default:flowing_water", "default:mossycobble"}, 7, -1, 5000, 4, 31000)
mobs:register_spawn("mobs:greenmedium", {"default:flowing_water", "default:mossycobble"}, 7, -1, 5000, 4, 31000)
mobs:register_spawn("mobs:greenbig", {"default:flowing_water", "default:mossycobble"}, 7, -1, 5000, 4, 31000)
mobs:register_egg("mobs:greenbig", "Green Slime", "spawn_egg_slime.png")



mobs:register_mob("mobs:lavasmall", {
	type = "monster",
	pathfinding = true,
	group_attack = true,
	hp_max = 15,
	collisionbox = {-0.2, -0.4, -0.2, 0.2, 0.2, 0.2},
	visual_size = {x=0.5, y=0.5},
	textures = {"lava_slime_top.png", "lava_slime_bottom.png", "lava_slime_front.png", "lava_slime_sides.png", "lava_slime_sides.png", "lava_slime_sides.png"},
	visual = "cube",
	blood_texture ="lava_slime_blood.png",
	rotate = 270,
	makes_footstep_sound = true,
	sounds = {
		jump = "green_slime_jump",
		death = "green_slime_death",
		damage = "green_slime_damage",
		attack = "green_slime_attack",
	},
	walk_velocity = .8,
	run_velocity = 2.6,
	damage = 1,
	armor = 100,
	drops = {
		{name = "tnt:gunpowder",
		chance = 3,
		min = 1,
		max = 1,},
		{name = "default:coal",
		chance = 1,
		min = 1,
		max = 5,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 10,
	lava_damage = 0,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 4,
	jump_chance = 98,
	fear_height = 12,	
})

mobs:register_mob("mobs:lavabig", {
	type = "monster",
	pathfinding = true,
	group_attack = true,
	hp_max = 15,
	collisionbox = {-0.75, -0.75, -0.75, 0.75, 0.75, 0.75},
	visual_size = {x=1.5, y=1.5},
	textures = {"lava_slime_top.png", "lava_slime_bottom.png", "lava_slime_front.png", "lava_slime_sides.png", "lava_slime_sides.png", "lava_slime_sides.png"},
	visual = "cube",
	blood_texture ="lava_slime_blood.png",
	rotate = 270,
	makes_footstep_sound = true,
	sounds = {
		jump = "green_slime_jump",
		death = "green_slime_death",
		damage = "green_slime_damage",
		attack = "green_slime_attack",
	},
	walk_velocity = .8,
	run_velocity = 1.6,
	damage = 2,
	armor = 100,
	drops = {
		{name = "tnt:gunpowder",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "mobs:lavasmall",
		chance = 1,
		min = 1,
		max = 5,},
	},
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	drawtype = "front",
	water_damage = 10,
	lava_damage = 0,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 8,
	jump_chance = 100,
	fear_height = 60,
	on_die =function(self, pos)
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:lavasmall")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:lavasmall")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:lavasmall")
		lavasmall = minetest.add_entity(self.object:getpos(), "mobs:lavasmall")
			ent = lavasmall:get_luaentity()
			end
})
mobs:register_spawn("mobs:lavasmall", {"nether:rack", "default:lava"}, 7, -1, 5000, 4, 31000)
mobs:register_spawn("mobs:lavabig", {"nether:rack", "default:lava"}, 7, -1, 5000, 4, 31000)
mobs:register_egg("mobs:lavabig", "Magma Cube", "spawn_egg_magma_cube.png")



mobs:register_mob("mobs:villager", {
	type = "animal",
	hp_max = 30,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.95, 0.4},
	textures = {"farmer.png"},
	visual = "mesh",
	mesh = "villager.x",
	makes_footstep_sound = true,
	walk_velocity = 1.2,
	run_velocity = 2.4,
	damage = 1,
	drops = {
		{name = "default:apple",
		chance = 100,
		min = 1,
		max = 2,},
	},
	armor = 200,
	sounds = {
		random = "Villager1",
		death = "Villagerdead",
		damage = "Villagerhurt1",
	},
	animation = {
		speed_normal = 30,
		speed_run = 60,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 49,
		run_start = 24,
		run_end = 49,
		hurt_start = 85,
		hurt_end = 115,
		death_start = 117,
		death_end = 145,
		shoot_start = 50,
		shoot_end = 82,
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	view_range = 16,
	fear_height = 5,
	on_rightclick = function(self, clicker)
		local inv
		inv = minetest.get_inventory({type="detached", name="trading_inv"})
		if not inv then
			inv = minetest.create_detached_inventory("trading_inv", {
				allow_take = function(inv, listname, index, stack, player)
					if listname == "output" then
						inv:remove_item("input", inv:get_stack("wanted", 1))
						minetest.sound_play("Villageraccept", {to_player = player:get_player_name()})
					end
					if listname == "input" or listname == "output" then
						return 1000
					else
						return 0
					end
				end,
				allow_put = function(inv, listname, index, stack, player)
					if listname == "input" then
						return 1000
					else
						return 0
					end
				end,
				on_put = function(inv, listname, index, stack, player)
					if inv:contains_item("input", inv:get_stack("wanted", 1)) then
						inv:set_stack("output", 1, inv:get_stack("offered", 1))
						minetest.sound_play("Villageraccept", {to_player = player:get_player_name()})
					else
						inv:set_stack("output", 1, ItemStack(""))
						minetest.sound_play("Villagerdeny", {to_player = player:get_player_name()})
					end
				end,
				on_move = function(inv, from_list, from_index, to_list, to_index, count, player)
					if inv:contains_item("input", inv:get_stack("wanted", 1)) then
						inv:set_stack("output", 1, inv:get_stack("offered", 1))
						minetest.sound_play("Villageraccept", {to_player = player:get_player_name()})
					else
						inv:set_stack("output", 1, ItemStack(""))
						minetest.sound_play("Villagerdeny", {to_player = player:get_player_name()})
					end
				end,
				on_take = function(inv, listname, index, stack, player)
					if inv:contains_item("input", inv:get_stack("wanted", 1)) then
						inv:set_stack("output", 1, inv:get_stack("offered", 1))
						minetest.sound_play("Villageraccept", {to_player = player:get_player_name()})
					else
						inv:set_stack("output", 1, ItemStack(""))
						minetest.sound_play("Villagerdeny", {to_player = player:get_player_name()})
					end
				end,
			})
			end
		inv:set_size("input", 1)
		inv:set_size("output", 1)
		inv:set_size("wanted", 1)
		inv:set_size("offered", 1)

		local trades = {
			{"default:apple 12",			"default:diamond 1"},
			{"default:coal_lump 20",		"default:diamond 1"},
			{"default:paper 30",			"default:diamond 1"},
			{"mobs:leather 10",			"default:diamond 1"},
			{"default:book 2",			"default:diamond 1"},
			{"default:diamond 3",		"default:diamond 1"},
			{"farming:potato 15",		"default:diamond 1"},
			{"farming:wheat 20",			"default:diamond 1"},
			{"farming:carrot 15",			"default:diamond 1"},
			{"farming:melon_8 8",		"default:diamond 1"},
			{"mobs:rotten_flesh 40",		"default:diamond 1"},
			{"default:gold_ingot 10",		"default:diamond 1"},
			{"farming:cotton 10",			"default:diamond 1"},
			{"wool:white 15",			"default:diamond 1"},
			{"farming:pumpkin 8",		"default:diamond 1"},

			{"default:diamond 1",		"mobs:beef_cooked 5"},
			{"default:diamond 1",		"mobs:chicken_cooked 7"},
			{"default:diamond 1",		"farming:cookie 6"},
			{"default:diamond 1",		"farming:pumpkin_bread 3"},
			{"default:diamond 1",		"mobs:arrow 10"},
			{"default:diamond 3",		"mobs:bow_wood 1"},
			{"default:diamond 8",		"fishing:pole_wood 1"},
			--{"default:diamond 4",		"potionspack:healthii 1"},
			{"default:diamond 1",		"cake:cake 1"},
			{"default:diamond 10",		"mobs:saddle 1"},
			--{"default:diamond 10",		"clock:1 1"},
			--{"default:diamondd 10",		"compass:0 1"},
			{"default:diamond 1",		"default:glass 5"},
			{"default:diamond 1",		"nether:glowstone 3"},
			{"default:diamond 3",		"mobs:shears 1"},
			{"default:diamond 10",		"default:sword_diamond 1"},
			{"default:diamond 20",		"3d_armor:chestplate_diamond 1"},
		}
		local tradenum = math.random(#trades)
		inv:set_stack("wanted", 1, ItemStack(trades[tradenum][1]))
		inv:set_stack("offered", 1, ItemStack(trades[tradenum][2]))
		
		local formspec = 
		"size[9,8.75]"..
		"background[-0.19,-0.25;9.41,9.49;trading_formspec_bg.png]"..
		"bgcolor[#080808BB;true]"..
		"listcolors[#9990;#FFF7;#FFF0;#160816;#D4D2FF]"..
		"list[current_player;main;0,4.5;9,3;9]"..
		"list[current_player;main;0,7.74;9,1;]"
		.."list[detached:trading_inv;wanted;2,1;1,1;]"
		.."list[detached:trading_inv;offered;5.75,1;1,1;]"
		.."list[detached:trading_inv;input;2,2.5;1,1;]"
		.."list[detached:trading_inv;output;5.75,2.5;1,1;]"
		minetest.sound_play("Villagertrade", {to_player = clicker:get_player_name()})
		minetest.show_formspec(clicker:get_player_name(), "tradespec", formspec)
	end,
})
mobs:register_spawn("mobs:villager", {"default:gravel"}, 20, 8, 50, 8, 31000)


-- Spider by AspireMint (fishyWET (CC-BY-SA 3.0 license for texture)
mobs:register_mob("mobs:spider", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	damage = 2,
	hp_min = 12,
	hp_max = 20,
	armor = 100,
	collisionbox = {-0.9, -0.01, -0.7, 0.7, 0.6, 0.7},
	visual = "mesh",
	mesh = "mobs_spider.x",
	textures = {
		"mobs_spider.png"
	},
	visual_size = {x=5,y=5},
	makes_footstep_sound = false,
	sounds = {
		random = "mobs_spider",
		attack = "mobs_spider",
	},
	walk_velocity = 1.7,
	run_velocity = 3.3,
	jump = true,
	view_range = 15,
	floats = 0,
	group_attack = true,
		replace_rate = 5,
	replace_what = {"default:torch"},
	replace_with = "air",
	replace_offset = -1,
	peaceful = false,
    drops = {
		{name = "farming:string",
		chance = 1, min = 1, max = 5,},
		{name = "esmobs:meat_raw",
		chance = 1, min = 0, max = 1,},
	},
	water_damage = 5,
	lava_damage = 50,
	light_damage = 0,
	fear_height = 14,
	animation = {
		speed_normal = 15,		speed_run = 15,
		stand_start = 1,		stand_end = 1,
		walk_start = 20,		walk_end = 40,
		run_start = 20,			run_end = 40,
		punch_start = 50,		punch_end = 90,
	},
})
mobs:register_spawn("esmobs:spider", {"default:stone" ,"default:gravel","default:cobble","group:crumbly", "group:cracky", "group:choppy", "group:snappy"}, 4, -1, 17000, 2, 3000)
mobs:register_egg("mobs:spider", "Spider", "mobs_cobweb.png", 1)

-- Cobweb
minetest.register_node("mobs:cobweb", {
	description = "Cobweb",
	drawtype = "plantlike",
	visual_scale = 1.1,
	tiles = {"mobs_cobweb.png"},
	inventory_image = "mobs_cobweb.png",
	paramtype = "light",
	sunlight_propagates = true,
	liquid_viscosity = 11,
	liquidtype = "source",
	liquid_alternative_flowing = "mobs:cobweb",
	liquid_alternative_source = "mobs:cobweb",
	liquid_renewable = false,
	liquid_range = 0,
	walkable = false,
	groups = {snappy=1,liquid=3},
	drop = "farming:cotton",
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_craft({
	output = "mobs:cobweb",
	recipe = {
		{"farming:string", "", "farming:string"},
		{"", "farming:string", ""},
		{"farming:string", "", "farming:string"},
	}
})

-- generic meat
minetest.register_craftitem("mobs:meat_raw", {
	description = "Raw Meat",
	inventory_image = "mobs_meat_raw.png",
})

minetest.register_craftitem("mobs:meat", {
	description = "Meat",
	inventory_image = "mobs_meat.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:meat",
	recipe = "mobs:meat_raw",
	cooktime = 5,
})

minetest.register_craftitem("mobs:rotten_flesh", {
	description = "Rotten Flesh",
	inventory_image = "mobs_rotten_flesh.png",
	on_use = minetest.item_eat(4),
})

-- beef
minetest.register_craftitem("mobs:beef_raw", {
	description = "Raw Beef",
	inventory_image = "beef_raw.png",
	on_use = minetest.item_eat(3),
})

minetest.register_craftitem("mobs:beef_cooked", {
	description = "Steak",
	inventory_image = "beef_cooked.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:beef_cooked",
	recipe = "mobs:beef_raw",
	cooktime = 5,
})

-- pork
minetest.register_craftitem("mobs:pork_raw", {
	description = "Raw Porkchop",
	inventory_image = "pork_raw.png",
	on_use = minetest.item_eat(3),
})

minetest.register_craftitem("mobs:pork_cooked", {
	description = "Cooked Porkchop",
	inventory_image = "pork_cooked.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:pork_cooked",
	recipe = "mobs:pork_raw",
	cooktime = 5,
})

--mutton
minetest.register_craftitem("mobs:meat_raw", {
	description = "Raw Mutton",
	inventory_image = "mobs_meat_raw.png",
	on_use = minetest.item_eat(4),
})

minetest.register_craftitem("mobs:meat", {
	description = "Cooked Mutton",
	inventory_image = "mobs_meat.png",
	on_use = minetest.item_eat(8),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:meat",
	recipe = "mobs:meat_raw",
	cooktime = 5,
})

-- chicken
minetest.register_craftitem("mobs:chicken_raw", {
	description = "Raw Chicken",
	inventory_image = "chicken_raw.png",
	on_use = minetest.item_eat(2),
})

minetest.register_craftitem("mobs:chicken_cooked", {
	description = "Cooked Chicken",
	inventory_image = "chicken_cooked.png",
	on_use = minetest.item_eat(6),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:chicken_cooked",
	recipe = "mobs:chicken_raw",
	cooktime = 5,
})

-- cooked rat, yummy!
minetest.register_craftitem("mobs:rat_cooked", {
	description = "Cooked Rat",
	inventory_image = "mobs_cooked_rat.png",
	on_use = minetest.item_eat(3),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:rat_cooked",
	recipe = "mobs:rat",
	cooktime = 5,
})



-- leather, feathers, etc.

minetest.register_craftitem("mobs:leather", {
	description = "Leather",
	inventory_image = "mobs_leather.png",
})

minetest.register_craftitem("mobs:feather", {
	description = "Feather",
	inventory_image = "mobs_feather.png",
})

minetest.register_craftitem("mobs:saddle", {
	description = "Saddle",
	inventory_image = "saddle.png",
})

minetest.register_tool("mobs:carrotstick", {
	description = "Carrot on a Stick",
	inventory_image = "carrot_on_a_stick.png",
	stack_max = 1,
})

minetest.register_craft({
	type = "shapeless",
	output = "mobs:carrotstick",
	recipe = {"fishing:pole_wood", "farming:carrot"},
})

minetest.register_craft({
	output = "mobs:saddle",
	recipe = {
		{"mobs:leather", "mobs:leather", "mobs:leather"},
		{"farming:string", "", "farming:string"},
	{"default:steel_ingot", "", "default:steel_ingot"}
	},
})

-- bucket of milk
minetest.register_craftitem("mobs:bucket_milk", {
	description = "Bucket of Milk",
	inventory_image = "mobs_bucket_milk.png",
	stack_max = 1,
	on_use = minetest.item_eat(8, 'bucket:bucket_empty'),
})

-- cheese wedge
minetest.register_craftitem("mobs:cheese", {
	description = "Cheese",
	inventory_image = "mobs_cheese.png",
	on_use = minetest.item_eat(4),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs:cheese",
	recipe = "mobs:bucket_milk",
	cooktime = 5,
	replacements = {{ "mobs:bucket_milk", "bucket:bucket_empty"}}
})

-- cheese block
minetest.register_node("mobs:cheeseblock", {
	description = "Cheese Block",
	tiles = {"mobs_cheeseblock.png"},
	is_ground_content = false,
	groups = {crumbly = 3},
	sounds = default.node_sound_dirt_defaults()
})

minetest.register_craft({
	output = "mobs:cheeseblock",
	recipe = {
		{'esmobs:cheese', 'esmobs:cheese', 'esmobs:cheese'},
		{'esmobs:cheese', 'esmobs:cheese', 'esmobs:cheese'},
		{'esmobs:cheese', 'esmobs:cheese', 'esmobs:cheese'},
	}
})

minetest.register_craft({
	output = "mobs:cheese 9",
	recipe = {
		{'mobs:cheeseblock'},
	}
})

-- nametag
minetest.register_craftitem("mobs:nametag", {
	description = "Nametag",
	inventory_image = "mobs_nametag.png",
})

core.register_craft({
	type = "shapeless",
	output = "mobs:nametag",
	recipe = {"default:paper", "dye:black", "farming:string"},
})

-- golden lasso
minetest.register_tool("mobs:magic_lasso", {
	description = "Magic Lasso (right-click animal to put in inventory)",
	inventory_image = "mobs_magic_lasso.png",
})

minetest.register_craft({
	output = "mobs:magic_lasso",
	recipe = {
		{"farming:string", "default:gold_lump", "farming:string"},
		{"default:gold_lump", "default:diamondblock", "default:gold_lump"},
		{"farming:string", "default:gold_lump", "farming:string"},
	}
})

-- net
minetest.register_tool("mobs:net", {
	description = "Net (right-click animal to put in inventory)",
	inventory_image = "mobs_net.png",
})

minetest.register_craft({
	output = "mobs:net",
	recipe = {
		{"default:stick", "", "default:stick"},
		{"default:stick", "", "default:stick"},
		{"farming:string", "default:stick", "farming:string"},
	}
})



-- shears (right click to shear animal)
minetest.register_tool("mobs:shears", {
	description = "Steel Shears (right-click to shear)",
	inventory_image = "mobs_shears.png",
})

minetest.register_craft({
	output = 'mobs:shears',
	recipe = {
		{'', 'default:steel_ingot', ''},
		{'', 'group:stick', 'default:steel_ingot'},
	}
})







--maikerumines throwing code
--arrow (weapon)
minetest.register_craftitem("mobs:arrow", {
	description = "ESM Arrow",
	inventory_image = "arrow.png",
})

minetest.register_node("mobs:arrow_box", {
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			-- Shaft
			{-6.5/17, -1.5/17, -1.5/17, 6.5/17, 1.5/17, 1.5/17},
			--Spitze
			{-4.5/17, 2.5/17, 2.5/17, -3.5/17, -2.5/17, -2.5/17},
			{-8.5/17, 0.5/17, 0.5/17, -6.5/17, -0.5/17, -0.5/17},
			--Federn
			{6.5/17, 1.5/17, 1.5/17, 7.5/17, 2.5/17, 2.5/17},
			{7.5/17, -2.5/17, 2.5/17, 6.5/17, -1.5/17, 1.5/17},
			{7.5/17, 2.5/17, -2.5/17, 6.5/17, 1.5/17, -1.5/17},
			{6.5/17, -1.5/17, -1.5/17, 7.5/17, -2.5/17, -2.5/17},

			{7.5/17, 2.5/17, 2.5/17, 8.5/17, 3.5/17, 3.5/17},
			{8.5/17, -3.5/17, 3.5/17, 7.5/17, -2.5/17, 2.5/17},
			{8.5/17, 3.5/17, -3.5/17, 7.5/17, 2.5/17, -2.5/17},
			{7.5/17, -2.5/17, -2.5/17, 8.5/17, -3.5/17, -3.5/17},
		}
	},
	tiles = {"throwing_arrow.png", "throwing_arrow.png", "throwing_arrow_back.png", "throwing_arrow_front.png", "throwing_arrow_2.png", "throwing_arrow.png"},
	groups = {not_in_creative_inventory=1},
})



local THROWING_ARROW_ENTITY={
	physical = false,
	timer=0,
	visual = "wielditem",
	visual_size = {x=0.1, y=0.1},
	textures = {"mobs:arrow_box"},
	--textures = {"esmobs:arrow.png"},
	velocity = 10,
	lastpos={},
	collisionbox = {0,0,0,0,0,0},
}


--ARROW CODE
THROWING_ARROW_ENTITY.on_step = function(self, dtime)
	self.timer=self.timer+dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

minetest.add_particle({
    pos = pos,
    vel = {x=0, y=0, z=0},
    acc = {x=0, y=0, z=0},
    expirationtime = .3,
    size = 1,
    collisiondetection = false,
    vertical = false,
    texture = "arrow_particle.png",
})

	if self.timer>0.2 then
		local objs = minetest.get_objects_inside_radius({x=pos.x,y=pos.y,z=pos.z}, 1.5)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "mobs:arrow_entity" and obj:get_luaentity().name ~= "__builtin:item" then
					local damage = 3
					minetest.sound_play("damage", {pos = pos})
					obj:punch(self.object, 1.0, {
						full_punch_interval=1.0,
						damage_groups={fleshy=damage},
					}, nil)
					self.object:remove()
				end
			else
				local damage = 3
				minetest.sound_play("damage", {pos = pos})
				obj:punch(self.object, 1.0, {
					full_punch_interval=1.0,
					damage_groups={fleshy=damage},
				}, nil)
				self.object:remove()
			end
		end
	end

	if self.lastpos.x~=nil then
		if node.name ~= "air" then
			minetest.sound_play("bowhit1", {pos = pos})
			--minetest.punch_node(pos)  --this crash game when bones for mobs used
			minetest.add_item(self.lastpos, 'mobs:arrow')
			self.object:remove()
		end
	end
	self.lastpos={x=pos.x, y=pos.y, z=pos.z}
end


minetest.register_entity("mobs:arrow_entity", THROWING_ARROW_ENTITY)


minetest.register_craft({
	output = 'mobs:arrow 48',
	recipe = {
		{'default:steel_ingot'},
		{'default:stick'},
		{'esmobs:feather'},
	}
})


arrows = {
	{"mobs:arrow", "mobs:arrow_entity" },
}

local throwing_shoot_arrow = function(itemstack, player)
	for _,arrow in ipairs(arrows) do
		if player:get_inventory():get_stack("main", player:get_wield_index()+1):get_name() == arrow[1] then
			if not minetest.setting_getbool("creative_mode") then
				player:get_inventory():remove_item("main", arrow[1])
			end
			local playerpos = player:getpos()
			--local obj = minetest.env:add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, arrow[2]) --current
			local obj = minetest.add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, arrow[2])  --mc
			local dir = player:get_look_dir()
			obj:setvelocity({x=dir.x*22, y=dir.y*22, z=dir.z*22})
			obj:setacceleration({x=dir.x*-3, y=-10, z=dir.z*-3})
			obj:setyaw(player:get_look_yaw()+math.pi)
			minetest.sound_play("throwing_sound", {pos=playerpos})
			if obj:get_luaentity().player == "" then
				obj:get_luaentity().player = player
			end
			obj:get_luaentity().node = player:get_inventory():get_stack("main", 1):get_name()
			return true
		end
	end
	return false
end

minetest.register_tool("mobs:bow_wood", {
	description = "ESM Wood Bow",
	inventory_image = "bow_standby.png",
    stack_max = 1,
	on_use = function(itemstack, user, pointed_thing)
		if throwing_shoot_arrow(itemstack, user, pointed_thing) then
			if not minetest.setting_getbool("creative_mode") then
				itemstack:add_wear(65535/50)
			end
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'mobs:bow_wood',
	recipe = {
		{'farming:cotton', 'default:stick', ''},
		{'farming:cotton', '',              'default:stick'},
		{'farming:cotton', 'default:stick', ''},
	}
})
--end maikerumine code


-- spawn eggs

mobs:register_egg("mobs:chicken", "Chicken", "spawn_egg_chicken.png")
mobs:register_egg("mobs:cow", "Cow", "spawn_egg_cow.png")
mobs:register_egg("mobs:creeper", "Creeper", "spawn_egg_creeper.png")
mobs:register_egg("mobs:pig", "Pig", "spawn_egg_pig.png")
mobs:register_egg("mobs:sheep", "Sheep", "spawn_egg_sheep.png")
mobs:register_egg("mobs:skeleton", "Skeleton", "spawn_egg_skeleton.png")
mobs:register_egg("mobs:zombie", "Zombie", "spawn_egg_zombie.png")
mobs:register_egg("mobs:pigman", "Zombie Pigman", "spawn_egg_zombie_pigman.png")
mobs:register_egg("mobs:villager", "Villager", "spawn_egg_villager.png")

if minetest.setting_get("log_mods") then
	minetest.log("action", "mobs loaded")
end
